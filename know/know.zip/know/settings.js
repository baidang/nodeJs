module.exports = { 
  cookieSecret: 'myKonw', 
  db: 'know', 
  host: 'localhost' 
}; 